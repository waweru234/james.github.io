// Function to sign up a new user
// Import the necessary Firebase modules from v11


  
  /* 
  Example usage:
  For sign up:
  signUpUser("john@example.com", "password123", "John Doe", "+123456789");
  
  For login:
  loginUser("john@example.com", "password123");
  */
  